import React from "react"
class EditComponent extends React.Component{
    render(){
        return(
            <div></div>
           
        )
    }
}

export default EditComponent
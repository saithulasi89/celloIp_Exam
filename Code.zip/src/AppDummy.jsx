import React, { Component } from 'react';  
import Hoc from './HOC';  
  
class App extends Component {  
  render() {  
    return (  
      <div>  
        <h2>HOC Example</h2>  
        JavaTpoint provides best CS tutorials.  
      </div>  
    )  
  }  
}  
App = Hoc(App);  
export default App; 
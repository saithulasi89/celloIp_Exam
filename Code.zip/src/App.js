import logo from './logo.svg';
import './App.css';
import React from 'react';
import { getProductList, addToCart, deleteProduct, updateProduct , addProduct,removeFromCart } from './actions'
import phone from "./phone.jpg"
import EditComponent from './editComponent';

class App extends React.Component {
  constructor(props) {
    super(props)
    this.store = this.props.store;
    this.state = {
      edit: false,
      productName: '',
      productCost: '',
      productId: null,
    }
  }

  componentWillMount() {
    this.store.dispatch(getProductList())
  }

  handleAddtoCart(id) {
    console.log(this.store.getState().productList)
    let item;
    this.store.getState().productList.map((product) => {
      if (product.id == id) {
        item = product
      }
    })
    this.store.dispatch(addToCart(item))
  }

  handleDelete(id) {
    this.store.dispatch(deleteProduct(id))
  }

  handleEditComponent(id) {
    let productt
    this.store.getState().productList.map((product) => {
      if (product.id == id) {
        productt = product
      }
    })
    this.setState({ edit: true, productName: productt.name, productCost: productt.price ,productId : id })
  }

  handleSubmit(e) {
    e.preventDefault();
    console.log('this.state.id---',this.state.productId)
    if(this.state.productId == null){
      let produt = {
        "id" : Math.random(),
        "name" : this.state.productName,
        "price":this.state.productCost
      }
      this.store.dispatch(addProduct(produt))
      this.setState({ edit: false, productName: '', productCost: '' ,productId :null})
      return;
    }
    let produt = {
      "id" : this.state.productId,
      "name" : this.state.productName,
      "price":this.state.productCost
    }
    this.store.dispatch(updateProduct(produt))
    this.setState({ edit: false, productName: '', productCost: '' ,productId :null})
  }

  UpdateProductName(event) {

    this.setState({ productName: event.target.value });
  }
  UpdateProductPrice(event) {

    this.setState({ productCost: event.target.value })
  }

  handleAddProduct(){
    this.setState({edit : true})
  }

  handleRemoveFromCart(id){
    this.store.dispatch(removeFromCart(id))
  }

  render() {
    let productList = this.store.getState().productList
    let cartItems = this.store.getState().cartProducts


    {/**  To render product components */}

    let products = productList.map((product) => (
      <div className="product">
        <div>
           <img src={phone}></img>
        </div>
       
        <p>{product.name}</p>
        <p>{product.price}</p>
        <div className = "button-AddtoCart">
           <button onClick={this.handleAddtoCart.bind(this, product.id)}>Add to Cart</button>
        </div>
       
        <div className="buttons">
          <button onClick={this.handleEditComponent.bind(this, product.id)} >Edit</button>
          <button onClick={this.handleDelete.bind(this, product.id)}>Delete</button>
        </div>

      </div>
    ))

    {/** to render cart details */}

    let cartDetails = cartItems.map((card) => (
      <tr>
        <td>{card.name}</td>
        <td>{card.price}</td>
        <td><button onClick={this.handleRemoveFromCart.bind(this,card.id)}>Remove from Cart</button></td>
      </tr>
    ))

    return (
      <div>
        {/** To handle form from add and update component */}
         {this.state.edit ?
          <div className="column">
            <form onSubmit={this.handleSubmit.bind(this)}>
              <div className="column">
                <label>Enter Product Name</label>
                <input type="text" value={this.state.productName} onChange={this.UpdateProductName.bind(this)} />
              </div>
              <div className="column">
                <label>Enter Product Price</label>
                <input type="text" value={this.state.productCost} onChange={this.UpdateProductPrice.bind(this)} />
              </div>
              <div>
                <button>Submit</button>
              </div>
            </form>
          </div>
          : ''}

        <div className="addToCart">
          <button onClick={this.handleAddProduct.bind(this)}>Add Product</button>
        </div>

        <div className="productList row">
          {products}
        </div>
        
        <div>
          Your cart details
          <table style={{ border: "1px" }}>
            <tr>
              <td>Name</td>
              <td>Quantity</td>

              <td>Action</td>
            </tr>
            {cartDetails}
          </table>
        </div>
       
      </div>

    )
  }
}

export default App;

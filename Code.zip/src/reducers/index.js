import { act } from "react-dom/cjs/react-dom-test-utils.production.min"
import productList from "../productList.json"
const initialState = {
    productList: '',
    updatedProduct: '',
    cartProducts: [],
}
export default (state = initialState, action) => {
    switch (action.type) {
        case 'GET_PRODUCT_LIST':
            console.log("Your choice is get product list!")
            return Object.assign({}, state, {
                productList: productList
            })
        case 'DELETE_PRODUCT':
            console.log("Your choice is delete product!", action.payload, state)
            let updatedProducts = state.productList.filter(product => product.id !== action.payload)
            return Object.assign({}, state, {
                productList: updatedProducts
            })

            case 'REMOVE_FROM_CART':
            console.log("Your choice is delete product!", action.payload, state)
            let updatedCartProducts = state.cartProducts.filter(product => product.id !== action.payload)
            return Object.assign({}, state, {
                cartProducts: updatedCartProducts
            })

        case 'ADD_PRODUCT':
            console.log("Your choice is delete product!", action.payload, state)

            return Object.assign({}, state, {
                productList: [...state.productList, action.payload]
            })
        case 'ADD_TO_CART':
            console.log("Your choice is add to cart!")
            return Object.assign({}, state, {
                cartProducts: [...state.cartProducts, action.payload]
            })

        case 'UPDATE_PRODUCT':
            console.log("Your choice is udate product!")
            let results = []
            let modifiedProducts = state.productList.map((product) => {

                if (product.id == action.payload.id) {
                    product.name = action.payload.name
                    product.price = action.payload.price
                }
                results.push(product)
            })
            return Object.assign({}, state, {
                productList: results
            })
        default:
            return state
    }
}